package com.cinejoy.tv;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

/**
 * A remote-friendly browser shell for CineJoy on Android TV / Google TV.
 *
 * Because websites can contain cross-origin video players, this app does not
 * attempt to extract streams or bypass playback protection. It displays the
 * original website inside the device's Android System WebView.
 */
public final class MainActivity extends Activity {
    private static final String HOME_URL = "https://cinejoy.pk/";
    private static final long LONG_PRESS_MS = 650L;

    private FrameLayout root;
    private FrameLayout fullscreenContainer;
    private LinearLayout controlBar;
    private CursorView cursorView;
    private TextView hintView;
    private TextView modeButton;
    private TextView desktopButton;
    private ProgressBar progressBar;
    private WebView webView;
    private String originalUserAgent;
    private String desktopUserAgent;
    private View fullscreenView;
    private WebChromeClient.CustomViewCallback fullscreenCallback;

    private boolean controlsOpen = false;
    private boolean cursorMode = true;
    private boolean desktopMode = false;
    private boolean selectHeld = false;
    private boolean selectLongPressed = false;

    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private final Runnable selectLongPress = new Runnable() {
        @Override public void run() {
            if (selectHeld && !controlsOpen) {
                selectLongPressed = true;
                showControls();
            }
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideSystemBars();
        buildUi();

        try {
            createBrowser(savedInstanceState);
        } catch (Throwable error) {
            showWebViewUnavailable();
        }
    }

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(7, 10, 18));
        setContentView(root);

        fullscreenContainer = new FrameLayout(this);
        fullscreenContainer.setBackgroundColor(Color.BLACK);
        fullscreenContainer.setVisibility(View.GONE);
        root.addView(fullscreenContainer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        cursorView = new CursorView(this);
        root.addView(cursorView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        progressBar.setVisibility(View.GONE);
        FrameLayout.LayoutParams progressLayout = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(3), Gravity.TOP);
        root.addView(progressBar, progressLayout);

        hintView = new TextView(this);
        hintView.setText("D-pad: move pointer   •   OK: click   •   HOLD OK: TV controls");
        hintView.setTextColor(Color.WHITE);
        hintView.setTextSize(14f);
        hintView.setPadding(dp(16), dp(10), dp(16), dp(10));
        hintView.setBackground(rounded(0xE6172232, 12, 0x8864829C));
        FrameLayout.LayoutParams hintLayout = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        hintLayout.bottomMargin = dp(20);
        root.addView(hintView, hintLayout);
        uiHandler.postDelayed(new Runnable() {
            @Override public void run() {
                if (hintView != null) hintView.setVisibility(View.GONE);
            }
        }, 12000);

        HorizontalScrollView scrollControls = new HorizontalScrollView(this);
        scrollControls.setHorizontalScrollBarEnabled(false);
        scrollControls.setFillViewport(false);
        scrollControls.setClipToPadding(false);
        scrollControls.setFocusable(false);
        scrollControls.setBackground(rounded(0xF0161D2B, 16, 0xFF3B4B64));

        controlBar = new LinearLayout(this);
        controlBar.setOrientation(LinearLayout.HORIZONTAL);
        controlBar.setGravity(Gravity.CENTER_VERTICAL);
        controlBar.setPadding(dp(14), dp(9), dp(14), dp(9));
        scrollControls.addView(controlBar);

        TextView brand = new TextView(this);
        brand.setText("CINEJOY  TV");
        brand.setTextSize(17f);
        brand.setTextColor(0xFF68E2D1);
        brand.setTypeface(null, 1);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        brand.setPadding(dp(10), dp(8), dp(20), dp(8));
        controlBar.addView(brand);

        addControl("Back", new View.OnClickListener() {
            @Override public void onClick(View v) { hideControls(); navigateBack(); }
        });
        addControl("Home", new View.OnClickListener() {
            @Override public void onClick(View v) {
                hideControls();
                if (webView != null) webView.loadUrl(HOME_URL);
            }
        });
        addControl("Reload", new View.OnClickListener() {
            @Override public void onClick(View v) {
                hideControls();
                if (webView != null) webView.reload();
            }
        });
        modeButton = addControl("Mode: Cursor", new View.OnClickListener() {
            @Override public void onClick(View v) {
                cursorMode = !cursorMode;
                modeButton.setText(cursorMode ? "Mode: Cursor" : "Mode: Scroll");
                hideControls();
                showHint(cursorMode ? "D-pad moves pointer; OK clicks" :
                        "D-pad scrolls the page; hold OK for controls");
            }
        });
        addControl("Play / Pause", new View.OnClickListener() {
            @Override public void onClick(View v) { hideControls(); toggleHtml5Video(); }
        });
        desktopButton = addControl("Desktop: Off", new View.OnClickListener() {
            @Override public void onClick(View v) {
                desktopMode = !desktopMode;
                desktopButton.setText(desktopMode ? "Desktop: On" : "Desktop: Off");
                if (webView != null) {
                    webView.getSettings().setUserAgentString(
                            desktopMode ? desktopUserAgent : originalUserAgent);
                    webView.reload();
                }
                hideControls();
            }
        });
        addControl("Zoom -", new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (webView != null) webView.zoomOut();
                hideControls();
            }
        });
        addControl("Zoom +", new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (webView != null) webView.zoomIn();
                hideControls();
            }
        });
        addControl("Close", new View.OnClickListener() {
            @Override public void onClick(View v) { hideControls(); }
        });

        FrameLayout.LayoutParams barLayout = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP);
        barLayout.setMargins(dp(18), dp(16), dp(18), 0);
        // The outer shell supplies the margins so controls are not cut off.
        FrameLayout barShell = new FrameLayout(this);
        barShell.addView(scrollControls, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        barShell.setVisibility(View.GONE);
        barShell.setTag("tvControls");
        root.addView(barShell, barLayout);
    }

    private TextView addControl(String name, View.OnClickListener listener) {
        final TextView button = new TextView(this);
        button.setText(name);
        button.setTextSize(14f);
        button.setTextColor(Color.WHITE);
        button.setGravity(Gravity.CENTER);
        button.setSingleLine(true);
        button.setPadding(dp(14), dp(11), dp(14), dp(11));
        button.setFocusable(true);
        button.setFocusableInTouchMode(true);
        button.setClickable(true);
        button.setBackground(rounded(0xFF273348, 12, 0xFF41536D));
        button.setOnClickListener(listener);
        button.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean hasFocus) {
                button.setBackground(hasFocus
                        ? rounded(0xFF246A78, 12, 0xFF80F6E4)
                        : rounded(0xFF273348, 12, 0xFF41536D));
                button.setScaleX(hasFocus ? 1.04f : 1f);
                button.setScaleY(hasFocus ? 1.04f : 1f);
            }
        });
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(44));
        p.rightMargin = dp(8);
        controlBar.addView(button, p);
        return button;
    }

    private void createBrowser(Bundle state) {
        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        root.addView(webView, 0, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        originalUserAgent = settings.getUserAgentString();
        desktopUserAgent = makeDesktopUserAgent(originalUserAgent);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                // Never launch arbitrary external apps from a web page.
                return scheme == null || (!scheme.equalsIgnoreCase("https")
                        && !scheme.equalsIgnoreCase("http"));
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request,
                                        WebResourceError error) {
                if (request.isForMainFrame()) {
                    Toast.makeText(MainActivity.this,
                            "Page couldn't load. Check Wi-Fi, then choose Reload.",
                            Toast.LENGTH_LONG).show();
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override public boolean onCreateWindow(WebView view, boolean isDialog,
                                                    boolean isUserGesture,
                                                    android.os.Message resultMsg) {
                // Third-party pop-up windows are not necessary for TV browsing.
                return false;
            }

            @Override public void onPermissionRequest(PermissionRequest request) {
                // Streaming doesn't need camera/microphone capture permissions.
                request.deny();
            }

            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                if (fullscreenView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                fullscreenView = view;
                fullscreenCallback = callback;
                fullscreenContainer.addView(view, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
                fullscreenContainer.setVisibility(View.VISIBLE);
                fullscreenContainer.bringToFront();
                cursorView.bringToFront();
                hintView.bringToFront();
                // Controls may be above the video when the remote opens them.
                getControlShell().bringToFront();
                progressBar.bringToFront();
                hideSystemBars();
            }

            @Override public void onHideCustomView() {
                exitVideoFullscreen();
            }
        });

        if (state != null && webView.restoreState(state) != null) {
            // Restore the prior browsing position when Android recreates the activity.
        } else {
            webView.loadUrl(HOME_URL);
        }
        webView.requestFocus();
    }

    private String makeDesktopUserAgent(String current) {
        // Reuse the installed WebView's actual Chromium version rather than
        // advertising a hard-coded browser version that could become outdated.
        String chromeVersion = "120.0.0.0";
        if (current != null) {
            int start = current.indexOf("Chrome/");
            if (start >= 0) {
                start += "Chrome/".length();
                int end = current.indexOf(' ', start);
                if (end < 0) end = current.length();
                if (end > start) chromeVersion = current.substring(start, end);
            }
        }
        return "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/" + chromeVersion + " Safari/537.36";
    }

    private void showWebViewUnavailable() {
        if (webView != null) {
            root.removeView(webView);
            webView = null;
        }
        cursorView.setVisibility(View.GONE);
        getControlShell().setVisibility(View.GONE);
        TextView message = new TextView(this);
        message.setText("CineJoy TV needs Android System WebView.\n\n" +
                "This projector/TV doesn't have a working WebView engine. " +
                "Update Android System WebView and the Google TV system software, " +
                "or use a TV-compatible browser.");
        message.setTextColor(Color.WHITE);
        message.setTextSize(22f);
        message.setGravity(Gravity.CENTER);
        message.setPadding(dp(60), dp(50), dp(60), dp(50));
        root.addView(message, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private View getControlShell() {
        return root.findViewWithTag("tvControls");
    }

    private void showControls() {
        View shell = getControlShell();
        if (shell == null) return;
        controlsOpen = true;
        shell.setVisibility(View.VISIBLE);
        shell.bringToFront();
        cursorView.setVisibility(View.GONE);
        hintView.setVisibility(View.GONE);
        // Focus on Back so a directional TV remote can use all controls.
        if (controlBar.getChildCount() > 1) controlBar.getChildAt(1).requestFocus();
    }

    private void hideControls() {
        View shell = getControlShell();
        if (shell != null) shell.setVisibility(View.GONE);
        controlsOpen = false;
        cursorView.setVisibility(cursorMode && webView != null ? View.VISIBLE : View.GONE);
        if (webView != null) webView.requestFocus();
    }

    private void showHint(String message) {
        hintView.setText(message);
        hintView.setVisibility(View.VISIBLE);
        hintView.bringToFront();
        uiHandler.postDelayed(new Runnable() {
            @Override public void run() {
                if (hintView != null) hintView.setVisibility(View.GONE);
            }
        }, 3500);
    }

    private void navigateBack() {
        if (fullscreenView != null) {
            exitVideoFullscreen();
        } else if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            finish();
        }
    }

    private void exitVideoFullscreen() {
        if (fullscreenView == null) return;
        fullscreenContainer.removeView(fullscreenView);
        fullscreenContainer.setVisibility(View.GONE);
        fullscreenView = null;
        WebChromeClient.CustomViewCallback cb = fullscreenCallback;
        fullscreenCallback = null;
        if (cb != null) cb.onCustomViewHidden();
        hideSystemBars();
    }

    private void toggleHtml5Video() {
        if (webView == null) return;
        String js = "(function(){var v=document.querySelector('video');" +
                "if(!v){var f=document.querySelectorAll('iframe');" +
                "for(var i=0;i<f.length;i++){try{v=f[i].contentDocument.querySelector('video');" +
                "if(v)break;}catch(e){}}}" +
                "if(!v)return false;if(v.paused){v.play();}else{v.pause();}return true;})()";
        webView.evaluateJavascript(js, result -> {
            if ("false".equals(result)) {
                Toast.makeText(MainActivity.this,
                        "Use the on-screen player button for embedded videos.",
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    /** Receive remote keys before the website can swallow the D-pad. */
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        int key = event.getKeyCode();
        boolean down = event.getAction() == KeyEvent.ACTION_DOWN;

        if (key == KeyEvent.KEYCODE_BACK || key == KeyEvent.KEYCODE_ESCAPE) {
            if (down) {
                if (controlsOpen) hideControls();
                else navigateBack();
            }
            return true;
        }

        if (key == KeyEvent.KEYCODE_MENU || key == KeyEvent.KEYCODE_BUTTON_START) {
            if (down && event.getRepeatCount() == 0) {
                if (controlsOpen) hideControls(); else showControls();
            }
            return true;
        }

        // Consume the key-up that finishes the long OK press which opened
        // the toolbar. Otherwise the focused Back button may get clicked.
        boolean selectKey = key == KeyEvent.KEYCODE_DPAD_CENTER ||
                key == KeyEvent.KEYCODE_ENTER || key == KeyEvent.KEYCODE_NUMPAD_ENTER ||
                key == KeyEvent.KEYCODE_BUTTON_A;
        if (controlsOpen && selectHeld && selectKey) {
            if (event.getAction() == KeyEvent.ACTION_UP) {
                uiHandler.removeCallbacks(selectLongPress);
                selectHeld = false;
                selectLongPressed = false;
            }
            return true;
        }

        // When the toolbar is open, the normal Android D-pad focus engine
        // selects a button. Do not redirect it to the website.
        if (controlsOpen) return super.dispatchKeyEvent(event);
        if (webView == null) return super.dispatchKeyEvent(event);

        if (key == KeyEvent.KEYCODE_DPAD_CENTER || key == KeyEvent.KEYCODE_ENTER ||
                key == KeyEvent.KEYCODE_NUMPAD_ENTER || key == KeyEvent.KEYCODE_BUTTON_A) {
            if (down) {
                if (!selectHeld) {
                    selectHeld = true;
                    selectLongPressed = false;
                    uiHandler.postDelayed(selectLongPress, LONG_PRESS_MS);
                }
                if (event.isLongPress() && !selectLongPressed) {
                    selectLongPressed = true;
                    uiHandler.removeCallbacks(selectLongPress);
                    showControls();
                }
            } else if (event.getAction() == KeyEvent.ACTION_UP) {
                uiHandler.removeCallbacks(selectLongPress);
                if (selectHeld && !selectLongPressed) {
                    if (cursorMode) clickAtPointer();
                    else showHint("Switch to Cursor mode to select a link");
                }
                selectHeld = false;
                selectLongPressed = false;
            }
            return true;
        }

        if (key == KeyEvent.KEYCODE_DPAD_UP || key == KeyEvent.KEYCODE_DPAD_DOWN ||
                key == KeyEvent.KEYCODE_DPAD_LEFT || key == KeyEvent.KEYCODE_DPAD_RIGHT) {
            if (down) {
                int distance = Math.min(dp(120), dp(33 + event.getRepeatCount() * 7));
                int dx = key == KeyEvent.KEYCODE_DPAD_RIGHT ? distance :
                        (key == KeyEvent.KEYCODE_DPAD_LEFT ? -distance : 0);
                int dy = key == KeyEvent.KEYCODE_DPAD_DOWN ? distance :
                        (key == KeyEvent.KEYCODE_DPAD_UP ? -distance : 0);
                if (cursorMode) {
                    cursorView.move(dx, dy);
                    if (dy > 0 && cursorView.isNearBottom()) webView.scrollBy(0, dp(60));
                    if (dy < 0 && cursorView.isNearTop()) webView.scrollBy(0, -dp(60));
                } else {
                    webView.scrollBy(dx * 3, dy * 3);
                }
            }
            return true;
        }

        if (down && (key == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE ||
                key == KeyEvent.KEYCODE_MEDIA_PLAY || key == KeyEvent.KEYCODE_MEDIA_PAUSE)) {
            toggleHtml5Video();
            return true;
        }
        // Let the projector's TV hardware handle volume and other system keys.
        return super.dispatchKeyEvent(event);
    }

    private void clickAtPointer() {
        View target = fullscreenView != null ? fullscreenContainer : webView;
        if (target == null) return;
        long time = SystemClock.uptimeMillis();
        float x = cursorView.getPointerX();
        float y = cursorView.getPointerY();
        MotionEvent press = MotionEvent.obtain(time, time, MotionEvent.ACTION_DOWN,
                x, y, 0);
        MotionEvent release = MotionEvent.obtain(time, time + 45,
                MotionEvent.ACTION_UP, x, y, 0);
        target.dispatchTouchEvent(press);
        target.dispatchTouchEvent(release);
        press.recycle();
        release.recycle();
        cursorView.pulse();
    }

    private void hideSystemBars() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    private GradientDrawable rounded(int bg, int radius, int stroke) {
        GradientDrawable result = new GradientDrawable();
        result.setColor(bg);
        result.setCornerRadius(dp(radius));
        result.setStroke(dp(1), stroke);
        return result;
    }

    private int dp(float value) {
        return (int) (getResources().getDisplayMetrics().density * value + .5f);
    }

    @Override public void onBackPressed() {
        if (controlsOpen) hideControls();
        else navigateBack();
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    @Override public void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
        hideSystemBars();
    }

    @Override protected void onDestroy() {
        uiHandler.removeCallbacksAndMessages(null);
        if (webView != null) {
            webView.stopLoading();
            root.removeView(webView);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    /** A non-clickable pointer painted over the site for TV remotes. */
    private final class CursorView extends View {
        private final Paint outer = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint inner = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float x = -1, y = -1;
        private long pulseUntil;

        CursorView(Context context) {
            super(context);
            setFocusable(false);
            setClickable(false);
            outer.setColor(Color.WHITE);
            outer.setStyle(Paint.Style.STROKE);
            outer.setStrokeWidth(dp(3));
            outer.setShadowLayer(dp(4), 0, dp(2), 0xFF000000);
            inner.setColor(0xFF64E7DC);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }

        @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            if (x < 0 || y < 0) { x = w * .5f; y = h * .5f; }
            x = clamp(x, dp(15), w - dp(15));
            y = clamp(y, dp(15), h - dp(15));
        }

        void move(int dx, int dy) {
            x = clamp(x + dx, dp(15), getWidth() - dp(15));
            y = clamp(y + dy, dp(15), getHeight() - dp(15));
            invalidate();
        }

        void pulse() {
            pulseUntil = SystemClock.uptimeMillis() + 180;
            invalidate();
            postDelayed(this::invalidate, 200);
        }

        float getPointerX() { return x; }
        float getPointerY() { return y; }
        boolean isNearBottom() { return y >= getHeight() - dp(50); }
        boolean isNearTop() { return y <= dp(50); }

        private float clamp(float value, float lo, float hi) {
            return Math.max(lo, Math.min(value, Math.max(lo, hi)));
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (x < 0 || y < 0) return;
            boolean pressed = SystemClock.uptimeMillis() < pulseUntil;
            float radius = dp(pressed ? 22 : 14);
            canvas.drawCircle(x, y, radius, outer);
            canvas.drawCircle(x, y, dp(4), inner);
            Paint p = inner;
            canvas.drawRoundRect(new RectF(x + dp(13), y + dp(8),
                    x + dp(33), y + dp(14)), dp(3), dp(3), p);
        }
    }
}
