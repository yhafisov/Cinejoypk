# CineJoy TV — Google TV / Android TV app

An Android TV launcher app that loads **https://cinejoy.pk/**, designed for
projectors and televisions operated with a directional remote.

## Features

- Listed under Google TV / Android TV's **Apps** launcher (Leanback banner included).
- Displays the CineJoy website without replacing or scraping its catalog.
- **D-pad pointer**: arrows move a virtual pointer; **OK** clicks wherever it points.
- **Hold OK for about 0.7 seconds** to open TV controls. This works on Google TV
  remotes without a MENU button. MENU also opens the controls if your remote has one.
- Toolbar: Back, Home, Reload, Cursor/Scroll toggle, HTML5 Play/Pause, Desktop
  site toggle, Zoom +/-, and Close.
- **Scroll mode** uses D-pad arrows to scroll long pages.
- Supports Android WebView fullscreen video requests and immersive landscape layout.
- Blocks separate pop-up windows. Uses the system's video/player support and
  does not attempt to bypass DRM or fetch streaming sources.
- Hardware/system remote volume keys are left to the projector's volume control.

## Build an APK for free using GitHub (no PC required)

1. Create a new GitHub repository, e.g. **CineJoyTV**, with the default branch **main**.
2. Extract `CineJoyTV-Source.zip` on your computer or phone.
3. In the repository, select **Add file → Upload files** and upload the **contents**
   of the `CineJoyTV` folder, not the ZIP itself. Preserve all folders, including
   `.github/workflows/build-apk.yml`, `app/`, and the two `.gradle` files.
4. Choose **Commit changes**. The GitHub Actions workflow should start automatically.
   If it does not, use **Actions → Build Google TV APK → Run workflow**.
   For a brand-new repo, GitHub might ask you to enable workflows first.
5. When the build has passed, open the workflow run, scroll to **Artifacts**, and
   download **CineJoyTV-AndroidTV-APK**. The download is a ZIP containing
   `app-debug.apk`. Extract that APK. It is debug-signed and installable.
6. Transfer `app-debug.apk` to the Google TV projector using a USB drive,
   compatible TV file manager, or the "Send Files to TV" method. On the TV,
   allow installing unknown apps for your file manager, open the APK, then
   choose **Install**. You will find **CineJoy TV** in your Apps list.

If your projector has USB debugging enabled, a simpler install method is:

```bash
adb connect TV_IP_ADDRESS:5555
adb install -r app-debug.apk
```

On some TVs, wireless debugging uses a pairing code and a different port;
use the connection instructions shown in the TV developer settings.

## Android Studio alternative

Open the extracted `CineJoyTV` project directory in Android Studio with
Android SDK API 35 installed and **Gradle 8.10.2** available, then choose
**Build → Build Bundle(s) / APK(s) → Build APK(s)**. The output is
`app/build/outputs/apk/debug/app-debug.apk`.

## TV remote controls

| Remote input | Action |
| --- | --- |
| D-pad arrows | Move the pointer, or scroll in Scroll mode |
| OK (short press) | Click where the pointer is |
| OK (hold ~0.7s) | Open TV controls |
| MENU, if present | Show/hide TV controls |
| BACK | Close TV controls; exit video fullscreen; go back; exit app |
| System volume keys | Projector/TV volume |

For a difficult-to-click site, switch **Mode: Scroll** to go down the page, then
switch back to **Mode: Cursor** to select an item. You can also use **Desktop: On**
if a page is laid out poorly for the screen.

## Compatibility and limitations

- This is **not a native CineJoy streaming client**: it displays the original
  website using Android System WebView and its existing player.
- **Website/player behavior has not been live-tested**. Video playback, third-party
  embeds, region restrictions, service uptime, and account requirements depend
  on the site and on the Google TV device's codecs/DRM capabilities.
- Android TV devices differ. A few **do not ship with a functional WebView**.
  In that case the app explains the missing dependency. Updating Android System
  WebView / Google TV might help; some devices may need a TV browser instead.
- Embedded players in **cross-origin iframes** cannot always be controlled by
  the toolbar's Play/Pause button. Use their visible on-screen play/pause button
  with the TV pointer. The app supports HTML5 fullscreen requests where the
  website/player implements them; it cannot force fullscreen in every player.
- Some streams depend on third-party cookies and even HTTP media resources.
  This app enables third-party cookies and compatibility mixed content for
  playback, so treat it as a browser and avoid entering sensitive credentials
  into untrusted embedded player pages.
- New-window pop-ups are blocked, though this does **not** guarantee all ads or
  in-page redirects are removed.

## Project structure

- `app/src/main/java/com/cinejoy/tv/MainActivity.java` — full TV application
- `app/src/main/AndroidManifest.xml` — TV launcher and permissions
- `app/src/main/res/drawable/` — TV banner and launcher icon
- `.github/workflows/build-apk.yml` — automated APK build

Target SDK 35, minimum SDK 23, Java 17, Android Gradle Plugin 8.7.3. No
paid account, proprietary API key, or other source library is required.
